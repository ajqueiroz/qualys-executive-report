"""
chart_export.py

Converts a Plotly figure to a static PNG, for embedding inline in an email
body - email clients strip <script> tags universally, so the interactive
HTML report's charts cannot render directly in an email; a static image is
the only thing that actually displays in an inbox.

Uses Playwright (render + screenshot) rather than Plotly's own kaleido
static-export path, because kaleido v1+ requires its own separate Chrome
download (`plotly_get_chrome`) which may not succeed in network-restricted
environments - Playwright's browser, if already installed for other
purposes, is reused here instead of adding a second Chrome dependency.

This entire module is OPTIONAL. If Playwright isn't installed or has no
browser downloaded, report_distribution.py falls back to a text/table-only
email body and simply attaches the full interactive report instead.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import plotly.graph_objects as go

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False


def figure_to_png_bytes(fig: go.Figure, width: int = 560, height: int = 300) -> bytes | None:
    """Returns PNG bytes for a Plotly figure, or None if Playwright/its
    browser isn't available - callers should handle None gracefully rather
    than let this raise, since this is explicitly a best-effort feature."""
    if not PLAYWRIGHT_AVAILABLE:
        return None

    html = fig.to_html(include_plotlyjs=True, full_html=True, config={"displayModeBar": False})

    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            html_path = Path(tmpdir) / "chart.html"
            html_path.write_text(html, encoding="utf-8")
            png_path = Path(tmpdir) / "chart.png"

            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page(viewport={"width": width, "height": height})
                page.goto(f"file://{html_path}")
                page.wait_for_timeout(400)
                page.screenshot(path=str(png_path))
                browser.close()

            return png_path.read_bytes()
    except Exception:
        # Browser not downloaded (playwright install chromium never run),
        # sandboxed environment blocks launching a browser, etc. - treat as
        # "static images unavailable" rather than crash report generation.
        return None
