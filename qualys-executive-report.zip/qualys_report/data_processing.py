"""
data_processing.py

All transformations needed for an executive vulnerability report, built on
top of a raw Qualys Host Detection DataFrame (HostId, IP, QID, Severity,
Status, FirstFound, LastFound) merged with the KnowledgeBase (QID, Title,
Category, CvssBase).

The trend-reconstruction logic here is the corrected version of the
technique from the "Create a Qualys Vulnerability Trend Chart in Power BI"
Reddit post reviewed earlier in this project - same core idea (a single pull
of ALL findings, active and fixed, has enough FIRST_FOUND/LAST_FOUND
information to reconstruct history without a time-series store), with the
off-by-one day errors and column-name typos from that post's DAX fixed here
in plain pandas.
"""

from __future__ import annotations

from datetime import datetime, timezone

import numpy as np
import pandas as pd

SEVERITY_LABELS = {1: "Minimal", 2: "Medium", 3: "Serious", 4: "Critical", 5: "Urgent"}


def merge_detections_with_kb(detections: pd.DataFrame, kb: pd.DataFrame) -> pd.DataFrame:
    """Joins raw detections to the KnowledgeBase on QID for readable titles/CVSS."""
    if detections.empty:
        return detections
    merged = detections.merge(kb, on="QID", how="left", suffixes=("", "_kb"))
    merged["SeverityLabel"] = merged["Severity"].map(SEVERITY_LABELS)
    merged["IsActive"] = merged["Status"].isin(["Active", "New", "Re-Opened"])
    merged["IsFixed"] = merged["Status"] == "Fixed"
    return merged


def build_date_spine(df: pd.DataFrame, end_date: datetime | None = None, display_days: int | None = None) -> pd.DataFrame:
    """One row per calendar day - the 'DateTable' equivalent from the Reddit
    post. By default spans the full detection history, but pass
    display_days to cap what's actually charted (e.g. the most recent 400
    days) while still using the FULL history for active/fixed calculations -
    a finding first detected before the display window still correctly
    counts as 'already active' on day 1 of the displayed range, rather than
    the chart misleadingly showing every environment ramping up from zero."""
    if df.empty:
        return pd.DataFrame({"Date": []})
    end = pd.Timestamp(end_date or datetime.now(timezone.utc)).normalize()
    earliest = df["FirstFound"].min().normalize()
    start = max(earliest, end - pd.Timedelta(days=display_days)) if display_days else earliest
    return pd.DataFrame({"Date": pd.date_range(start, end, freq="D", tz="UTC")})


def compute_daily_trend(df: pd.DataFrame, display_days: int = 400) -> pd.DataFrame:
    """
    Active vs Fixed vulnerability counts per day, for charting.

    display_days caps the CHARTED window (default ~13 months, enough for a
    real YoY comparison) while every active/fixed calculation still draws on
    the full detection history - so a finding first found before the
    charted window correctly counts as already-active on day 1 of the
    chart, rather than the chart implying the environment started at zero.

    Corrected logic vs. the Reddit post's DAX:
    - No +1 day offset (that post's boundary compensated for a time
      component that had already been stripped by an earlier formatting
      step - redundant and off by one once dates are pure dates).
    - "Fixed on day X" means LastFound falls exactly on X, not a
      >=/<= range that could double count.
    - "Active on day X" means FirstFound <= X AND (still active OR fixed
      strictly after X) - a finding fixed on day X counts as fixed that
      day, not still active.
    """
    if df.empty:
        return pd.DataFrame(columns=["Date", "ActiveCount", "FixedCount"])

    spine = build_date_spine(df, display_days=display_days)
    first_found = df["FirstFound"].dt.tz_localize(None).values
    last_found = df["LastFound"].dt.tz_localize(None).values
    is_fixed = df["IsFixed"].values

    active_counts = []
    fixed_counts = []
    for day in spine["Date"]:
        day_np = np.datetime64(day.tz_localize(None))
        found_by_day = first_found <= day_np
        fixed_after_day = (~is_fixed) | (last_found > day_np)
        active_counts.append(int((found_by_day & fixed_after_day).sum()))

        fixed_on_day = is_fixed & (pd.Series(last_found).dt.normalize().values == day_np)
        fixed_counts.append(int(fixed_on_day.sum()))

    spine["ActiveCount"] = active_counts
    spine["FixedCount"] = fixed_counts
    return spine


def compute_executive_kpis(df: pd.DataFrame) -> dict:
    """Top-line numbers for the report's hero section."""
    if df.empty:
        return {}

    active = df[df["IsActive"]]
    fixed = df[df["IsFixed"]]

    critical_high = active[active["Severity"] >= 4]

    mttr_days = None
    if not fixed.empty:
        remediation_time = (fixed["LastFound"] - fixed["FirstFound"]).dt.total_seconds() / 86400
        mttr_days = round(remediation_time.mean(), 1)

    trend = compute_daily_trend(df)
    mom_change_pct = None
    if len(trend) >= 31:
        current = trend["ActiveCount"].iloc[-1]
        month_ago = trend["ActiveCount"].iloc[-31]
        if month_ago > 0:
            mom_change_pct = round((current - month_ago) / month_ago * 100, 1)

    return {
        "total_active": int(len(active)),
        "total_fixed_period": int(len(fixed)),
        "critical_high_count": int(len(critical_high)),
        "unique_hosts_affected": int(active["HostId"].nunique()),
        "mttr_days": mttr_days,
        "mom_change_pct": mom_change_pct,
        "current_active_trend": int(trend["ActiveCount"].iloc[-1]) if not trend.empty else 0,
    }


def severity_distribution(df: pd.DataFrame) -> pd.DataFrame:
    active = df[df["IsActive"]]
    dist = active.groupby("SeverityLabel").size().reindex(
        ["Urgent", "Critical", "Serious", "Medium", "Minimal"], fill_value=0
    )
    return dist.reset_index(name="Count").rename(columns={"index": "SeverityLabel"})


def top_vulnerable_assets(df: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    active = df[df["IsActive"]]
    grouped = active.groupby(["HostId", "IP"]).agg(
        FindingCount=("QID", "count"),
        WeightedRisk=("Severity", "sum"),
    ).reset_index()
    return grouped.sort_values("WeightedRisk", ascending=False).head(n)


def top_prevalent_vulnerabilities(df: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    """Which single vulnerabilities affect the most hosts - the highest-
    leverage remediation targets ('fix this one thing everywhere')."""
    active = df[df["IsActive"]]
    grouped = active.groupby(["QID", "Title", "SeverityLabel"]).agg(
        AffectedHosts=("HostId", "nunique"),
    ).reset_index()
    return grouped.sort_values("AffectedHosts", ascending=False).head(n)


def remediation_aging(df: pd.DataFrame, as_of: datetime | None = None) -> pd.DataFrame:
    """SLA aging buckets for currently-active findings - the metric that
    tells leadership whether the org is meeting its own remediation SLAs."""
    active = df[df["IsActive"]].copy()
    if active.empty:
        return pd.DataFrame(columns=["Bucket", "Count"])

    now = pd.Timestamp(as_of or datetime.now(timezone.utc))
    age_days = (now - active["FirstFound"]).dt.total_seconds() / 86400

    bins = [-1, 30, 60, 90, np.inf]
    labels = ["0-30 days", "31-60 days", "61-90 days", "90+ days"]
    active["Bucket"] = pd.cut(age_days, bins=bins, labels=labels)

    result = active.groupby("Bucket", observed=False).size().reindex(labels, fill_value=0)
    return result.reset_index(name="Count").rename(columns={"index": "Bucket"})


def mttr_by_severity(df: pd.DataFrame) -> pd.DataFrame:
    fixed = df[df["IsFixed"]].copy()
    if fixed.empty:
        return pd.DataFrame(columns=["SeverityLabel", "AvgDaysToFix"])
    fixed["DaysToFix"] = (fixed["LastFound"] - fixed["FirstFound"]).dt.total_seconds() / 86400
    result = fixed.groupby("SeverityLabel")["DaysToFix"].mean().round(1)
    order = ["Urgent", "Critical", "Serious", "Medium", "Minimal"]
    return result.reindex(order).dropna().reset_index(name="AvgDaysToFix")


def _active_count_asof(df: pd.DataFrame, as_of: pd.Timestamp) -> int:
    """How many findings were active as of a specific point in time - the
    building block for both MoM and YoY comparisons."""
    if df.empty:
        return 0
    found_by = df["FirstFound"] <= as_of
    still_open = df["LastFound"].isna() | (~df["IsFixed"]) | (df["LastFound"] > as_of)
    return int((found_by & still_open).sum())


def _critical_high_count_asof(df: pd.DataFrame, as_of: pd.Timestamp) -> int:
    if df.empty:
        return 0
    found_by = df["FirstFound"] <= as_of
    still_open = df["LastFound"].isna() | (~df["IsFixed"]) | (df["LastFound"] > as_of)
    return int((found_by & still_open & (df["Severity"] >= 4)).sum())


def _mttr_for_window(df: pd.DataFrame, window_start: pd.Timestamp, window_end: pd.Timestamp) -> float | None:
    fixed = df[df["IsFixed"] & (df["LastFound"] >= window_start) & (df["LastFound"] < window_end)]
    if fixed.empty:
        return None
    days = (fixed["LastFound"] - fixed["FirstFound"]).dt.total_seconds() / 86400
    return round(days.mean(), 1)


def compute_period_comparisons(df: pd.DataFrame, as_of: datetime | None = None) -> dict:
    """
    This Month vs Last Month vs Same Month Last Year, for the metrics that
    matter to an executive audience: open exposure, critical/high count, and
    remediation speed. Returns raw values plus pre-computed % changes with
    'lower is better' semantics already applied (a decrease shows as
    improvement, matching the "down is good" convention for risk metrics -
    the opposite of a typical revenue KPI).
    """
    if df.empty:
        return {}

    now = pd.Timestamp(as_of or datetime.now(timezone.utc)).tz_localize(None)
    df = df.copy()
    df["FirstFound"] = df["FirstFound"].dt.tz_localize(None)
    df["LastFound"] = df["LastFound"].dt.tz_localize(None)

    this_month_start = now.replace(day=1)
    last_month_end = this_month_start
    last_month_start = (this_month_start - pd.Timedelta(days=1)).replace(day=1)
    year_ago_now = now - pd.DateOffset(years=1)
    year_ago_month_start = year_ago_now.replace(day=1)
    year_ago_month_end = (year_ago_month_start + pd.DateOffset(months=1))

    def pct_change(current, prior):
        if prior in (None, 0) or current is None:
            return None
        return round((current - prior) / prior * 100, 1)

    active_now = _active_count_asof(df, now)
    active_last_month = _active_count_asof(df, last_month_end - pd.Timedelta(days=1))
    active_year_ago = _active_count_asof(df, year_ago_month_end - pd.Timedelta(days=1))

    crit_now = _critical_high_count_asof(df, now)
    crit_last_month = _critical_high_count_asof(df, last_month_end - pd.Timedelta(days=1))
    crit_year_ago = _critical_high_count_asof(df, year_ago_month_end - pd.Timedelta(days=1))

    mttr_this_month = _mttr_for_window(df, this_month_start, now)
    mttr_last_month = _mttr_for_window(df, last_month_start, last_month_end)
    mttr_year_ago = _mttr_for_window(df, year_ago_month_start, year_ago_month_end)

    fixed_this_month = int(df[df["IsFixed"] & (df["LastFound"] >= this_month_start) & (df["LastFound"] <= now)].shape[0])
    fixed_last_month = int(df[df["IsFixed"] & (df["LastFound"] >= last_month_start) & (df["LastFound"] < last_month_end)].shape[0])
    fixed_year_ago = int(df[df["IsFixed"] & (df["LastFound"] >= year_ago_month_start) & (df["LastFound"] < year_ago_month_end)].shape[0])

    return {
        "as_of": now,
        "has_year_data": df["FirstFound"].min() <= year_ago_month_start,
        "active": {
            "current": active_now, "mom_prior": active_last_month, "yoy_prior": active_year_ago,
            "mom_pct": pct_change(active_now, active_last_month),
            "yoy_pct": pct_change(active_now, active_year_ago),
        },
        "critical_high": {
            "current": crit_now, "mom_prior": crit_last_month, "yoy_prior": crit_year_ago,
            "mom_pct": pct_change(crit_now, crit_last_month),
            "yoy_pct": pct_change(crit_now, crit_year_ago),
        },
        "mttr": {
            "current": mttr_this_month, "mom_prior": mttr_last_month, "yoy_prior": mttr_year_ago,
            "mom_pct": pct_change(mttr_this_month, mttr_last_month),
            "yoy_pct": pct_change(mttr_this_month, mttr_year_ago),
        },
        "fixed_count": {
            "current": fixed_this_month, "mom_prior": fixed_last_month, "yoy_prior": fixed_year_ago,
            "mom_pct": pct_change(fixed_this_month, fixed_last_month),
            "yoy_pct": pct_change(fixed_this_month, fixed_year_ago),
        },
    }


def sparkline_series(trend: pd.DataFrame, column: str, last_n_days: int = 60) -> list:
    """Last N days of a trend column, as a plain list - the data a sparkline needs."""
    if trend.empty:
        return []
    return trend[column].tail(last_n_days).tolist()
