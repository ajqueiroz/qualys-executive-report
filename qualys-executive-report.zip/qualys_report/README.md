# Qualys Executive Vulnerability Report

A standalone Python program that pulls directly from the Qualys VM API and
produces a single self-contained HTML report — no Power BI, no Log
Analytics, no intermediate database, no gateway.

## Quick start

```bash
pip install -r requirements.txt

# See what it looks like first, no Qualys account needed:
python run_report.py --demo --org "Your Company Name"

# Then run it for real:
python run_report.py --username YOUR_QUALYS_USER --password YOUR_QUALYS_PASS --org "Your Company Name"
```

Open `output/vulnerability_briefing.html` in any browser. It's a single
file — email it, put it on a share, open it offline. Plotly's charting
library is embedded directly in the file (not loaded from a CDN), which is
why the file is a few MB — this was a deliberate fix after testing showed
CDN-dependent charts can silently fail to render in restricted network
environments.

## Credentials

Prefer environment variables over the command line in any shared or logged
environment:

```bash
export QUALYS_USERNAME="your-username"
export QUALYS_PASSWORD="your-password"
python run_report.py --org "Your Company Name"
```

If your subscription is on a non-US Qualys platform, pass `--platform-url`
(e.g. `https://qualysapi.qualys.eu` for EU platform 3).

## What's actually in the report

- **Exposure trend** — active vs. fixed findings over time, reconstructed
  entirely from each finding's first/last-detected timestamps. This is the
  corrected version of a technique reviewed from a community Power BI
  tutorial during this project's research — same core idea, with that
  version's off-by-one-day and column-name bugs fixed here in plain pandas.
  The charted window is capped (~13 months) independently of the full
  detection history used for calculations, so the chart doesn't misleadingly
  show the environment "starting from zero."
- **Period comparison** — this month vs. last month vs. the same month last
  year, for open findings, critical/high count, remediation speed, and fix
  count. Delta badges use "lower is better" coloring for risk metrics (fewer
  open findings = green, even though the number went down) — the inverse of
  typical revenue-style KPI coloring.
- **Inline sparklines** next to the hero number — a compact trend shape,
  not a full chart, following the same convention used in tools like Cluvio
  and described in Edward Tufte's own notes on executive dashboards.
- **Severity distribution** and **remediation aging** (0-30 / 31-60 / 61-90
  / 90+ day buckets) — the SLA-compliance view leadership actually asks for.
- **Highest-leverage fixes** — single vulnerabilities affecting the most
  assets, i.e. where one remediation reduces exposure fleet-wide.
- **Highest-risk assets** — severity-weighted ranking, not just raw count.
- **Mean time to remediate, by severity.**

## Distribution

Send the report directly to a distribution list:

```bash
# Microsoft 365 / Exchange Online - USE THIS for M365 tenants:
python run_report.py --demo --org "Acme Corp" \
    --distribution-list distribution.txt \
    --from-address reports@acme.com \
    --send-via graph \
    --tenant-id $GRAPH_TENANT_ID --client-id $GRAPH_CLIENT_ID --client-secret $GRAPH_CLIENT_SECRET

# Generic SMTP (SendGrid, a relay, non-Microsoft mail):
python run_report.py --demo --org "Acme Corp" \
    --email-to alice@acme.com bob@acme.com --email-cc ciso@acme.com \
    --from-address reports@acme.com \
    --send-via smtp --smtp-host smtp.sendgrid.net --smtp-port 587 \
    --smtp-username apikey --smtp-password $SENDGRID_API_KEY
```

`distribution.txt` is one email address per line; `#` starts a comment.

**Why two send methods, and why Graph is the default:** Microsoft has
deprecated Basic Authentication for SMTP AUTH client submission in Exchange
Online. `smtp.office365.com` with a username/password will fail on most
current Microsoft 365 tenants unless an explicit legacy-auth exception was
granted. Graph's `sendMail` with an Entra app registration (client
credentials, `Mail.Send` **application** permission, admin-consented) is
the actual supported path today — the same Entra app-registration pattern
used for the Graph-based data pulls elsewhere in this project. Use
`send_via_smtp` only for non-Microsoft mail infrastructure.

**Every email includes a static, non-interactive summary in the body**
(KPI table + a plain PNG trend chart) plus the full interactive report as
an attachment — email clients strip `<script>` tags universally, so the
Plotly-based interactive charts cannot render inline in an email body no
matter what; a static image is the only thing that actually displays in an
inbox. Add `--no-inline-chart` to skip generating that image (faster, and
avoids the Playwright/Chromium dependency below) and send a table-only
summary instead.

**Optional dependency:** the inline chart image uses Playwright to render
and screenshot the chart (not Plotly's own `kaleido` static-export path,
which requires a separate Chrome download that may not succeed in
network-restricted environments). If Playwright or its browser isn't
installed, the email is sent with a text/table-only body automatically —
this never blocks sending, it just means no inline image.

```bash
pip install playwright
playwright install chromium
```

## Known limitations (be aware of these before relying on this in production)

- **Full Plotly.js is embedded per report** (~4-5 MB output file). Fine for
  email/sharing; if you're generating many reports on a schedule and
  storage matters, switch `include_plotlyjs` in `report_generator.py` back
  to `"cdn"` — but only if you've confirmed your viewers' environment can
  actually reach that CDN (this project's own testing found a real case
  where it silently couldn't).
- **Basic Auth over HTTPS** is what Qualys's VM API v2 supports; there's no
  OAuth/token option to switch to here. Qualys does have a newer JSON-based
  Host List Detection API (`POST /vmrs/api/1.0/host/list/detections`) in
  limited release as of this writing — worth migrating to once it's
  generally available, but not built against here since a limited-release
  endpoint may not be enabled on your specific subscription yet.
- **No retry/backoff on transient network failures** — a dropped connection
  mid-pagination currently just raises. Fine for a scheduled job with
  alerting; not fine unattended.
- **Graph sendMail's `from_address`** must be a mailbox your app
  registration is permitted to send as — scope this with an Exchange Online
  `ApplicationAccessPolicy` rather than granting tenant-wide send rights.

## Files

| File | Purpose |
|---|---|
| `qualys_client.py` | Real Qualys API client (auth, pagination, XML parsing) |
| `data_processing.py` | Pandas transformations, executive KPIs, period comparisons |
| `report_generator.py` | Plotly charts, sparklines, Jinja2 HTML rendering |
| `templates/report.html` | The report's visual design |
| `chart_export.py` | Static PNG export for email (Playwright-based) |
| `report_distribution.py` | Email sending via SMTP or Microsoft Graph |
| `demo_data.py` | Synthetic dataset for testing without a live account |
| `run_report.py` | CLI entry point |
