"""
run_report.py

Usage:
    python run_report.py --demo
        Runs against synthetic data - no Qualys account needed. Use this to
        verify the report looks right before pointing it at production.

    python run_report.py --username USER --password PASS --org "Acme Corp"
        Runs against your real Qualys subscription. Consider passing
        credentials via environment variables instead of the command line
        in any shared/logged environment - QUALYS_USERNAME / QUALYS_PASSWORD.

    Add distribution (either --demo or live, combine with the above):
        --email-to alice@acme.com bob@acme.com --email-cc ciso@acme.com
        --distribution-list distribution.txt   (one address per line, alternative to --email-to)

    Choose ONE send method:
        --send-via smtp --smtp-host smtp.sendgrid.net --smtp-port 587 \\
            --smtp-username apikey --smtp-password $SENDGRID_KEY --from-address reports@acme.com

        --send-via graph --tenant-id ... --client-id ... --client-secret ... \\
            --from-address reports@acme.com
        (Graph is the correct choice for Exchange Online / M365 - see
        report_distribution.py's module docstring for why SMTP AUTH against
        smtp.office365.com will likely fail on current tenants.)
"""

from __future__ import annotations

import argparse
import os
import sys

import data_processing as dp
import demo_data
import report_generator
import report_distribution as rd
import chart_export
from qualys_client import QualysClient, QualysCredentials


def _send_distribution(args, report_path, kpi, comparisons, narrative, trend):
    to_addresses = args.email_to or []
    if args.distribution_list:
        to_addresses = to_addresses + rd.load_distribution_list(args.distribution_list)
    if not to_addresses:
        return

    print(f"Preparing distribution to {len(to_addresses)} recipient(s) via {args.send_via}...")

    trend_png = None
    if not args.no_inline_chart:
        import plotly.graph_objects as go
        fig = go.Figure(go.Scatter(x=trend["Date"], y=trend["ActiveCount"], fill="tozeroy",
                                    line=dict(color=report_generator.COLORS["urgent"])))
        fig.update_layout(margin=dict(l=20, r=20, t=10, b=20), height=260)
        trend_png = chart_export.figure_to_png_bytes(fig)
        if trend_png is None:
            print("  Note: inline chart image unavailable (Playwright/browser not installed) - "
                  "sending a text/table-only summary instead. Run 'playwright install chromium' to enable it.")

    if args.send_via == "smtp":
        if args.dry_run:
            print(f"  [DRY RUN] Would send via SMTP ({args.smtp_host}:{args.smtp_port}) "
                  f"from {args.from_address} to {to_addresses} cc {args.email_cc or []}")
            return
        rd.send_via_smtp(
            smtp_host=args.smtp_host, smtp_port=args.smtp_port,
            smtp_username=args.smtp_username, smtp_password=args.smtp_password,
            from_address=args.from_address, to_addresses=to_addresses,
            cc_addresses=args.email_cc, report_path=report_path,
            kpi=kpi, comparisons=comparisons, narrative=narrative,
            trend_chart_png=trend_png,
        )
    elif args.send_via == "graph":
        if args.dry_run:
            print(f"  [DRY RUN] Would send via Graph sendMail from {args.from_address} "
                  f"to {to_addresses} cc {args.email_cc or []}")
            return
        rd.send_via_graph(
            tenant_id=args.tenant_id, client_id=args.client_id, client_secret=args.client_secret,
            from_address=args.from_address, to_addresses=to_addresses,
            cc_addresses=args.email_cc, report_path=report_path,
            kpi=kpi, comparisons=comparisons, narrative=narrative,
            trend_chart_png=trend_png,
        )
    else:
        sys.exit(f"--email-to/--distribution-list was set but --send-via was not 'smtp' or 'graph' (got: {args.send_via!r})")

    print("Distribution sent.")


def main():
    parser = argparse.ArgumentParser(description="Generate an executive Qualys vulnerability report.")
    parser.add_argument("--demo", action="store_true", help="Use synthetic demo data instead of a live Qualys account.")
    parser.add_argument("--username", default=os.environ.get("QUALYS_USERNAME"))
    parser.add_argument("--password", default=os.environ.get("QUALYS_PASSWORD"))
    parser.add_argument("--platform-url", default=os.environ.get("QUALYS_PLATFORM_URL", "https://qualysapi.qualys.com"))
    parser.add_argument("--org", default="Your Organization", help="Organization name shown in the report header.")
    parser.add_argument("--output", default="output/vulnerability_briefing.html")

    # Distribution
    parser.add_argument("--email-to", nargs="*", default=None, help="Recipient email addresses.")
    parser.add_argument("--email-cc", nargs="*", default=None, help="CC email addresses.")
    parser.add_argument("--distribution-list", default=None, help="Path to a text file, one email address per line.")
    parser.add_argument("--send-via", choices=["smtp", "graph"], default="graph", help="Distribution method if recipients are set.")
    parser.add_argument("--from-address", default=os.environ.get("REPORT_FROM_ADDRESS"))
    parser.add_argument("--no-inline-chart", action="store_true", help="Skip generating a static chart image for the email body (faster, no Playwright needed).")
    parser.add_argument("--dry-run", action="store_true", help="Build the email and print what would be sent, without actually sending it.")
    # SMTP-specific
    parser.add_argument("--smtp-host", default=os.environ.get("SMTP_HOST"))
    parser.add_argument("--smtp-port", type=int, default=int(os.environ.get("SMTP_PORT", 587)))
    parser.add_argument("--smtp-username", default=os.environ.get("SMTP_USERNAME"))
    parser.add_argument("--smtp-password", default=os.environ.get("SMTP_PASSWORD"))
    # Graph-specific
    parser.add_argument("--tenant-id", default=os.environ.get("GRAPH_TENANT_ID"))
    parser.add_argument("--client-id", default=os.environ.get("GRAPH_CLIENT_ID"))
    parser.add_argument("--client-secret", default=os.environ.get("GRAPH_CLIENT_SECRET"))

    args = parser.parse_args()

    # Credential hygiene: a password passed as a literal CLI argument is
    # visible to any other user/process on the same machine via `ps aux` or
    # /proc - a real exposure, not a theoretical one. Warn loudly rather
    # than silently accept it, even though the value still works either way.
    import sys as _sys
    for flag in ("--password", "--smtp-password", "--client-secret"):
        if flag in _sys.argv:
            print(f"WARNING: {flag} was passed as a command-line argument. This is visible to other "
                  f"processes on this machine (e.g. via 'ps aux'). Prefer the equivalent environment "
                  f"variable instead (see --help) in any shared or logged environment.")

    if args.demo:
        print("Generating from synthetic demo data (no live Qualys account contacted)...")
        detections, kb = demo_data.generate_demo_dataset()
    else:
        if not args.username or not args.password:
            sys.exit("Error: --username/--password (or QUALYS_USERNAME/QUALYS_PASSWORD env vars) are required unless --demo is set.")
        print(f"Connecting to {args.platform_url} ...")
        client = QualysClient(QualysCredentials(args.username, args.password, args.platform_url))
        print("Fetching host detections (paginated - this can take a while on large subscriptions)...")
        detections, kb = client.fetch_full_dataset()
        print(f"Retrieved {len(detections):,} detection records across {detections['HostId'].nunique():,} hosts.")

    output_path = report_generator.generate_report(detections, kb, args.output, org_name=args.org)
    print(f"Report written to: {output_path}")

    if args.email_to or args.distribution_list:
        if not args.from_address:
            sys.exit("Error: --from-address (or REPORT_FROM_ADDRESS env var) is required when sending to recipients.")
        df = dp.merge_detections_with_kb(detections, kb)
        kpi = dp.compute_executive_kpis(df)
        comparisons = dp.compute_period_comparisons(df)
        narrative = report_generator._narrative_summary(kpi, comparisons)
        trend = dp.compute_daily_trend(df)
        _send_distribution(args, output_path, kpi, comparisons, narrative, trend)


if __name__ == "__main__":
    main()
