"""
report_distribution.py

Two ways to send the report to a distribution list:

1. send_via_smtp()  - generic SMTP (SendGrid, an on-prem relay, any ESP).
2. send_via_graph() - Microsoft Graph sendMail. USE THIS for Exchange
   Online / Microsoft 365 tenants: Microsoft has deprecated Basic
   Authentication for SMTP AUTH client submission, so smtp.office365.com
   with a username/password will fail on most current tenants unless an
   explicit legacy-auth exception was granted. Graph's sendMail with an
   Entra app registration (client credentials, Mail.Send application
   permission) is the actual supported path today.

Both build the SAME email: an inline, email-safe HTML summary (KPI table +
static chart images, since email clients strip <script> tags and cannot run
the interactive Plotly report inline) with the full interactive HTML report
attached for anyone who wants to open it in a real browser.
"""

from __future__ import annotations

import base64
import smtplib
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from pathlib import Path

import requests

import chart_export


def load_distribution_list(path: str) -> list[str]:
    """Reads one email address per line from a plain text file - the
    simplest possible distribution-list format, easy to maintain without
    touching code. Blank lines and lines starting with # are ignored."""
    addresses = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            addresses.append(line)
    return addresses


def _build_email_safe_body(kpi: dict, comparisons: dict, narrative: str, chart_images: dict[str, bytes]) -> tuple[str, list[MIMEImage]]:
    """
    Builds the HTML that goes IN THE EMAIL BODY (not the attachment) - no
    <script>, no interactive Plotly, just a table and inline CID-referenced
    images, which is what actually survives Outlook/Gmail's HTML sanitizer.
    """
    image_parts = []
    image_tags = {}
    for name, png_bytes in chart_images.items():
        if png_bytes is None:
            image_tags[name] = "<p style='color:#888;font-size:0.85rem'>[Chart image unavailable - see attached report]</p>"
            continue
        cid = f"{name}_image"
        img = MIMEImage(png_bytes)
        img.add_header("Content-ID", f"<{cid}>")
        img.add_header("Content-Disposition", "inline")
        image_parts.append(img)
        image_tags[name] = f'<img src="cid:{cid}" style="max-width:100%;border:1px solid #ddd;" />'

    def delta_span(pct, lower_is_better=True):
        if pct is None:
            return "—"
        is_good = (pct < 0) if lower_is_better else (pct > 0)
        color = "#4F7358" if is_good else "#C1432A"
        arrow = "▼" if pct < 0 else ("▲" if pct > 0 else "—")
        return f'<span style="color:{color};font-weight:600">{arrow} {abs(pct):.1f}%</span>'

    active = comparisons.get("active", {})
    crit = comparisons.get("critical_high", {})

    html = f"""
    <div style="font-family:Arial,sans-serif;color:#10192B;max-width:640px;">
      <h2 style="font-family:Georgia,serif;font-weight:normal;">Vulnerability Exposure Briefing</h2>
      <p style="font-size:15px;line-height:1.5;">{narrative}</p>

      <table style="width:100%;border-collapse:collapse;margin:16px 0;font-size:14px;">
        <tr style="border-bottom:2px solid #10192B;">
          <th style="text-align:left;padding:6px;">Metric</th>
          <th style="text-align:center;padding:6px;">Current</th>
          <th style="text-align:center;padding:6px;">vs. Last Month</th>
          <th style="text-align:center;padding:6px;">vs. Last Year</th>
        </tr>
        <tr style="border-bottom:1px solid #ddd;">
          <td style="padding:6px;">Open Findings</td>
          <td style="text-align:center;padding:6px;">{active.get('current','—')}</td>
          <td style="text-align:center;padding:6px;">{delta_span(active.get('mom_pct'))}</td>
          <td style="text-align:center;padding:6px;">{delta_span(active.get('yoy_pct'))}</td>
        </tr>
        <tr style="border-bottom:1px solid #ddd;">
          <td style="padding:6px;">Critical / Urgent Open</td>
          <td style="text-align:center;padding:6px;">{crit.get('current','—')}</td>
          <td style="text-align:center;padding:6px;">{delta_span(crit.get('mom_pct'))}</td>
          <td style="text-align:center;padding:6px;">{delta_span(crit.get('yoy_pct'))}</td>
        </tr>
      </table>

      <p style="font-weight:600;margin-top:20px;">Exposure Over Time</p>
      {image_tags.get('trend', '')}

      <p style="font-size:12px;color:#888;margin-top:24px;">
        This is a static summary for inbox viewing. Open the attached report for the full
        interactive version (severity breakdown, remediation aging, highest-risk assets and more).
      </p>
    </div>
    """
    return html, image_parts


def _build_message(
    subject: str,
    to_addresses: list[str],
    cc_addresses: list[str],
    body_html: str,
    inline_images: list[MIMEImage],
    attachment_path: str,
) -> MIMEMultipart:
    msg = MIMEMultipart("related")
    msg["Subject"] = subject
    msg["To"] = ", ".join(to_addresses)
    if cc_addresses:
        msg["Cc"] = ", ".join(cc_addresses)

    msg.attach(MIMEText(body_html, "html"))
    for img in inline_images:
        msg.attach(img)

    attachment_bytes = Path(attachment_path).read_bytes()
    part = MIMEApplication(attachment_bytes, _subtype="html")
    part.add_header("Content-Disposition", "attachment", filename=Path(attachment_path).name)
    msg.attach(part)

    return msg


def send_via_smtp(
    smtp_host: str,
    smtp_port: int,
    smtp_username: str,
    smtp_password: str,
    from_address: str,
    to_addresses: list[str],
    report_path: str,
    kpi: dict,
    comparisons: dict,
    narrative: str,
    cc_addresses: list[str] | None = None,
    subject: str | None = None,
    use_tls: bool = True,
    trend_chart_png: bytes | None = None,
):
    """Generic SMTP send. Works with SendGrid, most ESPs, and on-prem relays.
    Will NOT work against smtp.office365.com on most current Microsoft 365
    tenants - use send_via_graph() for those instead."""
    body_html, inline_images = _build_email_safe_body(kpi, comparisons, narrative, {"trend": trend_chart_png})
    msg = _build_message(
        subject or "Vulnerability Exposure Briefing",
        to_addresses, cc_addresses or [], body_html, inline_images, report_path,
    )
    msg["From"] = from_address

    with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
        if use_tls:
            server.starttls()
        server.login(smtp_username, smtp_password)
        all_recipients = to_addresses + (cc_addresses or [])
        server.sendmail(from_address, all_recipients, msg.as_string())


def send_via_graph(
    tenant_id: str,
    client_id: str,
    client_secret: str,
    from_address: str,
    to_addresses: list[str],
    report_path: str,
    kpi: dict,
    comparisons: dict,
    narrative: str,
    cc_addresses: list[str] | None = None,
    subject: str | None = None,
    trend_chart_png: bytes | None = None,
):
    """
    Sends via Microsoft Graph's sendMail - the correct path for Exchange
    Online / Microsoft 365 given Basic Auth SMTP AUTH deprecation.

    Requires an Entra app registration with the Mail.Send APPLICATION
    permission (admin-consented), client-credentials auth - the same
    pattern used for the Graph-based tables built earlier in this project.
    from_address must be a mailbox the app registration is permitted to
    send as (Exchange Online 'ApplicationAccessPolicy' can scope this down
    to specific mailboxes rather than every mailbox in the tenant).
    """
    token_resp = requests.post(
        f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
        data={
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": "https://graph.microsoft.com/.default",
            "grant_type": "client_credentials",
        },
        timeout=30,
    )
    token_resp.raise_for_status()
    access_token = token_resp.json()["access_token"]

    body_html, _ = _build_email_safe_body(kpi, comparisons, narrative, {"trend": trend_chart_png})

    attachment_b64 = base64.b64encode(Path(report_path).read_bytes()).decode("ascii")

    message = {
        "message": {
            "subject": subject or "Vulnerability Exposure Briefing",
            "body": {"contentType": "HTML", "content": body_html},
            "toRecipients": [{"emailAddress": {"address": a}} for a in to_addresses],
            "ccRecipients": [{"emailAddress": {"address": a}} for a in (cc_addresses or [])],
            "attachments": [{
                "@odata.type": "#microsoft.graph.fileAttachment",
                "name": Path(report_path).name,
                "contentType": "text/html",
                "contentBytes": attachment_b64,
            }],
        },
        "saveToSentItems": "true",
    }

    resp = requests.post(
        f"https://graph.microsoft.com/v1.0/users/{from_address}/sendMail",
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        json=message,
        timeout=60,
    )
    if resp.status_code >= 300:
        raise RuntimeError(f"Graph sendMail failed ({resp.status_code}): {resp.text[:500]}")
