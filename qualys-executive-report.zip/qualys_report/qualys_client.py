"""
qualys_client.py

Real Qualys API client. Handles the two authentication/parsing problems that
break most first attempts at this (confirmed against the Power BI community
threads and Reddit trend-chart post referenced in this project's research):

1. Basic Auth must be built manually - Qualys's API frequently rejects
   credentials passed through generic "Basic auth" dialogs in low-code tools.
2. The XML responses are deeply nested (HOST_LIST > HOST > DETECTION_LIST >
   DETECTION) - this client flattens that with pandas rather than requiring
   manual per-record expansion.

Security notes:
- XML is parsed with entity resolution and network access disabled
  (see _SAFE_XML_PARSER) to prevent XXE (XML External Entity) injection -
  a real vulnerability class for any code parsing XML from a network
  source, not a Qualys-specific concern, but worth closing by default
  rather than assuming the source is always trustworthy.
- Credentials are only ever placed in the Authorization header, never in a
  URL or query string (so they can't leak into logs, browser history, or
  proxy access logs the way a query-string credential would).
- Nothing in this file logs or prints the password, the encoded auth
  header, or the access token used by report_distribution.py's Graph path.

Rate limiting: implements Qualys's documented X-RateLimit-* /
X-Concurrency-Limit-* headers (confirmed against docs.qualys.com) -
proactively backs off when close to the window limit, and on an actual 409
(rate-limited) or 5xx response, sleeps for the server-specified
X-RateLimit-ToWait-Sec (or an exponential backoff if that header is absent)
and retries rather than failing the whole pull over one blocked call.
"""

from __future__ import annotations

import base64
import logging
import time
from dataclasses import dataclass
from typing import Optional

import pandas as pd
import requests
from lxml import etree

logger = logging.getLogger("qualys_client")

# XXE protection: disallow entity resolution and any network access the
# parsed document might try to trigger via DOCTYPE/ENTITY declarations.
_SAFE_XML_PARSER = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=False)

MAX_RETRIES = 5
BASE_BACKOFF_SECONDS = 2


class QualysAPIError(Exception):
    """Raised on non-200 responses or unparseable XML from the Qualys API."""


@dataclass
class QualysCredentials:
    username: str
    password: str
    platform_url: str = "https://qualysapi.qualys.com"  # change for EU/other platforms


class QualysClient:
    """
    Thin wrapper around the Qualys VM API v2.0 (Host List Detection and
    KnowledgeBase endpoints). Both return XML; both are flattened to a
    pandas DataFrame before being handed back.
    """

    def __init__(self, credentials: QualysCredentials, timeout: int = 120):
        self.creds = credentials
        self.timeout = timeout
        auth_bytes = f"{credentials.username}:{credentials.password}".encode("utf-8")
        self._auth_header = "Basic " + base64.b64encode(auth_bytes).decode("ascii")
        # A session reuses the TCP/TLS connection across calls (faster,
        # fewer handshakes) rather than opening a fresh connection per request.
        self._session = requests.Session()

    def _headers(self) -> dict:
        return {
            "X-Requested-With": "python-qualys-executive-report",
            "Authorization": self._auth_header,
        }

    def _handle_rate_limit_headers(self, resp: requests.Response) -> None:
        """Proactively slow down before we get blocked, rather than only
        reacting after a 409. Cheap insurance against burning the window."""
        remaining = resp.headers.get("X-RateLimit-Remaining")
        window_sec = resp.headers.get("X-RateLimit-Window-Sec")
        if remaining is not None and int(remaining) <= 1 and window_sec:
            wait = min(int(window_sec), 60)  # cap the proactive wait; a real 409 will tell us the true figure if this isn't enough
            logger.info(f"Qualys rate limit nearly exhausted (remaining={remaining}) - pausing {wait}s before continuing.")
            time.sleep(wait)

    def _get(self, path: str, params: dict) -> bytes:
        url = f"{self.creds.platform_url}{path}"

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                resp = self._session.get(url, headers=self._headers(), params=params, timeout=self.timeout)
            except requests.exceptions.RequestException as exc:
                if attempt == MAX_RETRIES:
                    raise QualysAPIError(f"Network error calling {path} after {MAX_RETRIES} attempts: {exc}") from exc
                backoff = BASE_BACKOFF_SECONDS * (2 ** (attempt - 1))
                logger.warning(f"Network error on attempt {attempt}/{MAX_RETRIES} ({exc}); retrying in {backoff}s.")
                time.sleep(backoff)
                continue

            if resp.status_code == 200:
                self._handle_rate_limit_headers(resp)
                return resp.content

            if resp.status_code == 409:
                # Rate-limited or a concurrency-limit conflict. Qualys tells
                # us exactly how long to wait - use that instead of guessing.
                wait = int(resp.headers.get("X-RateLimit-ToWait-Sec", BASE_BACKOFF_SECONDS * (2 ** (attempt - 1))))
                if attempt == MAX_RETRIES:
                    raise QualysAPIError(
                        f"Qualys API still rate-limited after {MAX_RETRIES} attempts on {path} "
                        f"(would need to wait {wait}s more)."
                    )
                logger.warning(f"Qualys rate limit hit (409) on attempt {attempt}/{MAX_RETRIES}; waiting {wait}s per X-RateLimit-ToWait-Sec.")
                time.sleep(wait)
                continue

            if resp.status_code >= 500:
                # Transient server-side issue - worth retrying; a 4xx other
                # than 409 (bad auth, bad params) is not, so those raise immediately below.
                if attempt == MAX_RETRIES:
                    raise QualysAPIError(f"Qualys API returned {resp.status_code} for {path} after {MAX_RETRIES} attempts: {resp.text[:500]}")
                backoff = BASE_BACKOFF_SECONDS * (2 ** (attempt - 1))
                logger.warning(f"Qualys API {resp.status_code} on attempt {attempt}/{MAX_RETRIES}; retrying in {backoff}s.")
                time.sleep(backoff)
                continue

            # Any other non-200 (401 bad credentials, 400 bad params, etc.)
            # is not something a retry will fix - fail immediately with the
            # response body to make the actual problem visible.
            raise QualysAPIError(f"Qualys API returned {resp.status_code} for {path}: {resp.text[:500]}")

        raise QualysAPIError(f"Exhausted retries calling {path} without a definitive success or failure.")

    def fetch_host_detections(
        self,
        active_kernels_only: bool = False,
        truncation_limit: int = 500,
        max_pages: int = 200,
    ) -> pd.DataFrame:
        """
        Pulls Host List Detection data (every finding, active AND fixed),
        paginating through the full result set.

        Qualys's own docs confirm: hosts are returned sorted by host ID
        ascending, and when more records exist than truncation_limit, the
        response is truncated - the standard continuation pattern (also
        used by the community PowerShell scripts referenced during this
        project's research) is to track the highest HOST ID seen on each
        page and request id_min=<that + 1> for the next page, stopping once
        a page returns fewer hosts than truncation_limit (i.e. the last page).

        IMPORTANT: do NOT filter this to active-only if you want trend/
        remediation-history charts downstream - fixed findings' FIRST_FOUND/
        LAST_FOUND dates are what makes historical trend reconstruction
        possible without a separate time-series store.
        """
        all_frames = []
        id_min = None
        for page_num in range(max_pages):
            params = {
                "action": "list",
                "show_results": 1,
                "output_format": "XML",
                "truncation_limit": truncation_limit,
            }
            if id_min is not None:
                params["id_min"] = id_min

            xml_bytes = self._get("/api/2.0/fo/asset/host/vm/detection/", params)
            page_df, host_ids = self._parse_host_detections(xml_bytes, return_host_ids=True)

            if page_df.empty:
                break
            all_frames.append(page_df)

            if len(host_ids) < truncation_limit:
                break  # last page - fewer hosts than the page size means nothing follows
            id_min = max(host_ids) + 1
            time.sleep(0.5)  # light self-throttling between pages
        else:
            raise QualysAPIError(
                f"Hit max_pages={max_pages} without reaching the last page - "
                "either raise max_pages or check id_min continuation logic."
            )

        if not all_frames:
            return pd.DataFrame()
        return pd.concat(all_frames, ignore_index=True)

    def fetch_knowledgebase(self, truncation_limit: int = 1000, max_pages: int = 200) -> pd.DataFrame:
        """Pulls the QID -> vulnerability metadata (title, CVSS, category)
        lookup, paginated the same way as fetch_host_detections (QID is the
        ascending sort key here rather than host ID)."""
        all_frames = []
        id_min = None
        for _ in range(max_pages):
            params = {"action": "list", "details": "Basic", "truncation_limit": truncation_limit}
            if id_min is not None:
                params["id_min"] = id_min

            xml_bytes = self._get("/api/2.0/fo/knowledge_base/vuln/", params)
            page_df, qids = self._parse_knowledgebase(xml_bytes, return_qids=True)

            if page_df.empty:
                break
            all_frames.append(page_df)

            if len(qids) < truncation_limit:
                break
            id_min = max(qids) + 1
            time.sleep(0.5)
        else:
            raise QualysAPIError(f"Hit max_pages={max_pages} pulling KnowledgeBase without reaching the last page.")

        if not all_frames:
            return pd.DataFrame()
        return pd.concat(all_frames, ignore_index=True)

    # ---- XML parsing -----------------------------------------------------

    @staticmethod
    def _text(node, tag: str) -> Optional[str]:
        el = node.find(tag)
        return el.text if el is not None and el.text else None

    def _parse_host_detections(self, xml_bytes: bytes, return_host_ids: bool = False):
        root = etree.fromstring(xml_bytes, parser=_SAFE_XML_PARSER)
        rows = []
        host_ids = []
        for host in root.iter("HOST"):
            host_id = self._text(host, "ID")
            if host_id is not None:
                try:
                    host_ids.append(int(host_id))
                except ValueError:
                    pass
            ip = self._text(host, "IP")
            dns = self._text(host, "DNS")
            det_list = host.find("DETECTION_LIST")
            if det_list is None:
                continue
            for det in det_list.iter("DETECTION"):
                rows.append({
                    "HostId": host_id,
                    "IP": ip,
                    "DNS": dns,
                    "QID": self._text(det, "QID"),
                    "Type": self._text(det, "TYPE"),
                    "Severity": self._text(det, "SEVERITY"),
                    "Status": self._text(det, "STATUS"),
                    "FirstFound": self._text(det, "FIRST_FOUND_DATETIME"),
                    "LastFound": self._text(det, "LAST_FOUND_DATETIME"),
                })
        df = pd.DataFrame(rows)
        if not df.empty:
            df["QID"] = pd.to_numeric(df["QID"], errors="coerce")
            df["Severity"] = pd.to_numeric(df["Severity"], errors="coerce")
            df["FirstFound"] = pd.to_datetime(df["FirstFound"], errors="coerce", utc=True)
            df["LastFound"] = pd.to_datetime(df["LastFound"], errors="coerce", utc=True)

        if return_host_ids:
            return df, host_ids
        return df

    def _parse_knowledgebase(self, xml_bytes: bytes, return_qids: bool = False):
        root = etree.fromstring(xml_bytes, parser=_SAFE_XML_PARSER)
        rows = []
        qids = []
        for vuln in root.iter("VULN"):
            qid_text = self._text(vuln, "QID")
            if qid_text is not None:
                try:
                    qids.append(int(qid_text))
                except ValueError:
                    pass
            cvss_el = vuln.find("CVSS/BASE")
            rows.append({
                "QID": qid_text,
                "Title": self._text(vuln, "TITLE"),
                "Category": self._text(vuln, "CATEGORY"),
                "CvssBase": cvss_el.text if cvss_el is not None and cvss_el.text else None,
                "PatchAvailable": self._text(vuln, "PATCHABLE"),
            })
        df = pd.DataFrame(rows)
        if not df.empty:
            df["QID"] = pd.to_numeric(df["QID"], errors="coerce")
            df["CvssBase"] = pd.to_numeric(df["CvssBase"], errors="coerce")

        if return_qids:
            return df, qids
        return df

    def fetch_full_dataset(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Convenience: pulls both endpoints, with a short pause to stay well
        under Qualys's rate limits on subsequent calls."""
        detections = self.fetch_host_detections()
        time.sleep(1)
        kb = self.fetch_knowledgebase()
        return detections, kb
