"""
report_generator.py

Builds every chart (Plotly, embedded as interactive HTML/JS - no image
export step, no Power BI, no gateway) and renders the final report through
the Jinja2 template in templates/report.html.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
from jinja2 import Environment, FileSystemLoader

import data_processing as dp

TEMPLATE_DIR = Path(__file__).parent / "templates"

COLORS = {
    "ink": "#10192B",
    "steel": "#3E6C86",
    "steel_light": "#7FA6BC",
    "urgent": "#C1432A",
    "gold": "#B8862B",
    "sage": "#4F7358",
    "paper": "#F6F5F1",
    "line": "#D8D4C9",
}

SEVERITY_COLOR = {
    "Urgent": COLORS["urgent"],
    "Critical": "#D9713C",
    "Serious": COLORS["gold"],
    "Medium": COLORS["steel_light"],
    "Minimal": "#B9C4C8",
}

PLOTLY_LAYOUT_DEFAULTS = dict(
    font=dict(family="Inter, -apple-system, sans-serif", size=13, color=COLORS["ink"]),
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=10, r=10, t=10, b=10),
)


def _fig_to_div(fig: go.Figure, include_js: bool = False) -> str:
    # Plotly.js is embedded directly (not loaded from a CDN) so the report
    # is a single self-contained file - works offline, in email, and isn't
    # at the mercy of a corporate network blocking external CDN scripts
    # from a local file:// page (confirmed to actually happen in testing,
    # not a hypothetical - see build notes).
    return fig.to_html(full_html=False, include_plotlyjs=include_js, config={"displayModeBar": False})


def build_trend_chart(trend: pd.DataFrame) -> str:
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=trend["Date"], y=trend["ActiveCount"], name="Active",
        mode="lines", line=dict(color=COLORS["urgent"], width=2.5),
        fill="tozeroy", fillcolor="rgba(193,67,42,0.08)",
    ))
    fig.add_trace(go.Bar(
        x=trend["Date"], y=trend["FixedCount"], name="Fixed (that day)",
        marker_color=COLORS["sage"], opacity=0.65,
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT_DEFAULTS,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        height=340,
        xaxis=dict(showgrid=False, linecolor=COLORS["line"]),
        yaxis=dict(showgrid=True, gridcolor=COLORS["line"], zeroline=False, title="Findings"),
    )
    # include_js=False here: the sparklines are rendered earlier in the page
    # (in the hero section) and are the ones that embed the Plotly library -
    # HTML executes scripts in document order, so whichever chart appears
    # FIRST on the page must be the one carrying the library, not this one.
    return _fig_to_div(fig, include_js=False)


def build_severity_chart(dist: pd.DataFrame) -> str:
    fig = go.Figure(go.Bar(
        x=dist["Count"], y=dist["SeverityLabel"], orientation="h",
        marker_color=[SEVERITY_COLOR.get(s, COLORS["steel"]) for s in dist["SeverityLabel"]],
        text=dist["Count"], textposition="outside",
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT_DEFAULTS,
        showlegend=False,
        height=240,
        xaxis=dict(showgrid=False, visible=False),
        yaxis=dict(showgrid=False, autorange="reversed"),
    )
    return _fig_to_div(fig)


def build_aging_chart(aging: pd.DataFrame) -> str:
    bucket_colors = [COLORS["sage"], COLORS["gold"], "#D9713C", COLORS["urgent"]]
    fig = go.Figure(go.Bar(
        x=aging["Bucket"], y=aging["Count"],
        marker_color=bucket_colors[: len(aging)],
        text=aging["Count"], textposition="outside",
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT_DEFAULTS,
        showlegend=False,
        height=240,
        xaxis=dict(showgrid=False, linecolor=COLORS["line"]),
        yaxis=dict(showgrid=True, gridcolor=COLORS["line"], visible=False),
    )
    return _fig_to_div(fig)


def build_mttr_chart(mttr: pd.DataFrame) -> str:
    if mttr.empty:
        return "<p style='color:#888'>No fixed findings in this period to compute remediation time.</p>"
    fig = go.Figure(go.Bar(
        x=mttr["AvgDaysToFix"], y=mttr["SeverityLabel"], orientation="h",
        marker_color=[SEVERITY_COLOR.get(s, COLORS["steel"]) for s in mttr["SeverityLabel"]],
        text=mttr["AvgDaysToFix"].astype(str) + "d", textposition="outside",
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT_DEFAULTS,
        showlegend=False,
        height=220,
        xaxis=dict(showgrid=False, visible=False),
        yaxis=dict(showgrid=False, autorange="reversed"),
    )
    return _fig_to_div(fig)


def _hex_to_rgba(hex_color: str, alpha: float = 0.12) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{alpha})"


def build_sparkline(values: list, color: str, include_js: bool = False) -> str:
    """A true sparkline: no axes, no gridlines, no legend - just the shape
    of the trend, meant to sit inline next to a KPI number, not stand alone."""
    if not values or len(values) < 2:
        return ""
    fig = go.Figure(go.Scatter(
        y=values, mode="lines", line=dict(color=color, width=2),
        fill="tozeroy", fillcolor=_hex_to_rgba(color),
    ))
    fig.update_layout(
        margin=dict(l=0, r=0, t=0, b=0), height=40, width=120,
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(visible=False), yaxis=dict(visible=False),
        showlegend=False,
    )
    return fig.to_html(full_html=False, include_plotlyjs=include_js, config={"displayModeBar": False, "staticPlot": True})


def _delta_html(pct, lower_is_better: bool = True) -> dict:
    """Delta formatting with 'down is good' semantics for risk metrics -
    a decrease in vulnerability count is improvement (green), not decline,
    which is the inverse of how most business KPIs color their deltas."""
    if pct is None:
        return {"text": "—", "css_class": "flat", "arrow": ""}
    is_improvement = (pct < 0) if lower_is_better else (pct > 0)
    arrow = "▼" if pct < 0 else ("▲" if pct > 0 else "—")
    css_class = "good" if is_improvement else ("flat" if pct == 0 else "bad")
    return {"text": f"{arrow} {abs(pct):.1f}%", "css_class": css_class, "arrow": arrow}


def _narrative_summary(kpi: dict, comparisons: dict) -> str:
    """A short, human-written-feeling paragraph generated from the KPIs -
    the thing that makes a report read as 'executive' rather than 'raw data
    dump'. Per security-dashboard reporting guidance, this should state one
    explicit story ('we closed X, reducing exposure by Y%'), not just list
    numbers - so year-over-year framing is stated in plain language here,
    not left for the reader to infer from a table."""
    direction = "held steady"
    if kpi.get("mom_change_pct") is not None:
        if kpi["mom_change_pct"] > 5:
            direction = f"increased {kpi['mom_change_pct']}%"
        elif kpi["mom_change_pct"] < -5:
            direction = f"decreased {abs(kpi['mom_change_pct'])}%"

    mttr_note = (
        f"Findings that were remediated this period took an average of {kpi['mttr_days']} days to fix."
        if kpi.get("mttr_days") is not None else
        "No findings were closed in this period."
    )

    yoy_note = ""
    yoy_pct = comparisons.get("active", {}).get("yoy_pct")
    if comparisons.get("has_year_data") and yoy_pct is not None:
        if yoy_pct < 0:
            yoy_note = f" Compared to this same month last year, open exposure is down {abs(yoy_pct):.0f}% — the program is meaningfully ahead of where it stood twelve months ago."
        elif yoy_pct > 0:
            yoy_note = f" Compared to this same month last year, open exposure is up {yoy_pct:.0f}%, which is worth flagging even if the short-term trend looks stable."

    return (
        f"The organization currently carries {kpi['total_active']:,} open findings across "
        f"{kpi['unique_hosts_affected']:,} assets, of which {kpi['critical_high_count']:,} are rated "
        f"Critical or Urgent. Overall exposure has {direction} compared to 30 days ago. {mttr_note}{yoy_note}"
    )


def generate_report(
    detections: pd.DataFrame,
    kb: pd.DataFrame,
    output_path: str,
    org_name: str = "Your Organization",
) -> str:
    df = dp.merge_detections_with_kb(detections, kb)

    kpi = dp.compute_executive_kpis(df)
    trend = dp.compute_daily_trend(df)
    severity = dp.severity_distribution(df)
    aging = dp.remediation_aging(df)
    top_assets = dp.top_vulnerable_assets(df)
    top_vulns = dp.top_prevalent_vulnerabilities(df)
    mttr = dp.mttr_by_severity(df)
    comparisons = dp.compute_period_comparisons(df)

    # Sparklines: active-count trend (red) and fixed-count trend (green),
    # last 60 days, sitting inline beside their respective KPI numbers.
    active_spark = build_sparkline(dp.sparkline_series(trend, "ActiveCount"), COLORS["urgent"], include_js=True)
    fixed_spark = build_sparkline(dp.sparkline_series(trend, "FixedCount"), COLORS["sage"])

    deltas = {
        "active_mom": _delta_html(comparisons.get("active", {}).get("mom_pct")),
        "active_yoy": _delta_html(comparisons.get("active", {}).get("yoy_pct")),
        "crit_mom": _delta_html(comparisons.get("critical_high", {}).get("mom_pct")),
        "crit_yoy": _delta_html(comparisons.get("critical_high", {}).get("yoy_pct")),
        "mttr_mom": _delta_html(comparisons.get("mttr", {}).get("mom_pct")),
        "mttr_yoy": _delta_html(comparisons.get("mttr", {}).get("yoy_pct")),
        "fixed_mom": _delta_html(comparisons.get("fixed_count", {}).get("mom_pct"), lower_is_better=False),
        "fixed_yoy": _delta_html(comparisons.get("fixed_count", {}).get("yoy_pct"), lower_is_better=False),
    }

    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))
    template = env.get_template("report.html")

    html = template.render(
        org_name=org_name,
        generated_at=datetime.now().strftime("%B %d, %Y at %H:%M"),
        kpi=kpi,
        comparisons=comparisons,
        deltas=deltas,
        active_spark=active_spark,
        fixed_spark=fixed_spark,
        narrative=_narrative_summary(kpi, comparisons),
        trend_chart=build_trend_chart(trend),
        severity_chart=build_severity_chart(severity),
        aging_chart=build_aging_chart(aging),
        mttr_chart=build_mttr_chart(mttr),
        top_assets=top_assets.to_dict("records"),
        top_vulns=top_vulns.to_dict("records"),
        severity_colors=SEVERITY_COLOR,
    )

    Path(output_path).write_text(html, encoding="utf-8")
    return output_path
