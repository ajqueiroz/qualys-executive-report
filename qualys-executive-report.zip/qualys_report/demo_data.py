"""
demo_data.py

Generates a synthetic dataset shaped exactly like what QualysClient returns,
so the report can be built and verified end-to-end without a live Qualys
account. Clearly for demonstration only - swap for QualysClient.fetch_full_dataset()
against real credentials in production.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)

VULN_CATALOG = [
    (91234, "OpenSSL Heartbleed Information Disclosure", 5, "Vulnerability"),
    (91987, "Apache Log4j Remote Code Execution (Log4Shell)", 5, "Vulnerability"),
    (90876, "Microsoft Windows SMBv1 Remote Code Execution", 4, "Vulnerability"),
    (86543, "Unsupported Windows Server 2012 R2 Detected", 4, "Vulnerability"),
    (105234, "TLS 1.0/1.1 Protocol Detected", 3, "Vulnerability"),
    (105891, "Missing Security Patch for Chrome Browser", 3, "Vulnerability"),
    (38739, "SSH Weak Algorithms Supported", 2, "Vulnerability"),
    (105991, "SSL Certificate Expiring Soon", 2, "Vulnerability"),
    (11827, "DNS Server Cache Snooping Remote Information Disclosure", 2, "Vulnerability"),
    (86000, "Self-Signed SSL Certificate", 1, "Vulnerability"),
    (91555, "Docker Remote API Unauthenticated Access", 5, "Vulnerability"),
    (90111, "Outdated OpenSSH Version", 4, "Vulnerability"),
    (105444, "Weak Password Policy on Local Accounts", 3, "Vulnerability"),
    (48123, "SNMP Default Community String", 3, "Vulnerability"),
    (105777, "Redis Server Unauthenticated Access", 5, "Vulnerability"),
]

CVSS_BY_SEVERITY = {5: 9.5, 4: 7.8, 3: 5.4, 2: 3.6, 1: 1.2}


def _knowledgebase_df() -> pd.DataFrame:
    rows = [
        {"QID": qid, "Title": title, "Category": "Security", "CvssBase": CVSS_BY_SEVERITY[sev], "PatchAvailable": "YES"}
        for qid, title, sev, _t in VULN_CATALOG
    ]
    return pd.DataFrame(rows)


def _host_detections_df(n_hosts: int = 240, days_of_history: int = 420) -> pd.DataFrame:
    now = pd.Timestamp.now(tz="UTC").normalize()
    # Generate findings starting well before the visible reporting window
    # (an extra ~365 days of lead-in) so the environment already looks
    # steady-state by the time the reporting window begins, rather than
    # ramping up from zero - a genuinely more realistic simulation, and one
    # that avoids a distorted year-over-year comparison (an early
    # near-zero baseline makes any YoY % change meaningless).
    generation_days = days_of_history + 365
    start = now - pd.Timedelta(days=generation_days)

    rows = []
    for host_idx in range(n_hosts):
        host_id = f"H{100000 + host_idx}"
        ip = f"10.{RNG.integers(0, 4)}.{RNG.integers(0, 255)}.{RNG.integers(1, 254)}"
        dns = f"host-{host_idx:04d}.corp.internal"

        n_findings = RNG.integers(1, 9)
        chosen = RNG.choice(len(VULN_CATALOG), size=n_findings, replace=False)

        for vidx in chosen:
            qid, title, sev, _t = VULN_CATALOG[vidx]
            first_found = start + pd.Timedelta(days=int(RNG.integers(0, generation_days)))

            # Higher severity findings get fixed faster and more often (more realistic
            # than uniform random - mirrors typical SLA-driven remediation behavior).
            fix_probability = {5: 0.75, 4: 0.65, 3: 0.45, 2: 0.25, 1: 0.15}[sev]
            is_fixed = RNG.random() < fix_probability

            if is_fixed:
                mttr_target_days = {5: 5, 4: 12, 3: 25, 2: 40, 1: 60}[sev]
                days_to_fix = max(1, int(RNG.normal(mttr_target_days, mttr_target_days * 0.4)))
                last_found = min(first_found + pd.Timedelta(days=days_to_fix), now)
                status = "Fixed"
                if last_found >= now:
                    last_found = now - pd.Timedelta(hours=1)
            else:
                last_found = now - pd.Timedelta(days=int(RNG.integers(0, 5)))
                status = RNG.choice(["Active", "New", "Re-Opened"], p=[0.7, 0.2, 0.1])

            rows.append({
                "HostId": host_id, "IP": ip, "DNS": dns,
                "QID": qid, "Type": "Vulnerability", "Severity": sev,
                "Status": status, "FirstFound": first_found, "LastFound": last_found,
            })

    df = pd.DataFrame(rows)
    df["FirstFound"] = pd.to_datetime(df["FirstFound"], utc=True)
    df["LastFound"] = pd.to_datetime(df["LastFound"], utc=True)
    return df


def generate_demo_dataset() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Returns (detections, knowledgebase) in the exact shape QualysClient produces."""
    return _host_detections_df(), _knowledgebase_df()
